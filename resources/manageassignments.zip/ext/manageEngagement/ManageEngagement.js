sap.ui.define(["sap/m/MessageToast"],function(e){"use strict";return{editEngagement:function(n){e.show("Custom handler invoked.")}}});
//# sourceMappingURL=ManageEngagement.js.map