sap.ui.define(["sap/m/MessageToast"],function(s){"use strict";return{editAssignment:function(s){}}});
//# sourceMappingURL=AssignmentController.js.map